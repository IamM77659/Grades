package com.mycompany.cc006arraydemo;

import java.util.Scanner;

/**
 *
 * @author lebro
 */
public class ArrayWorks {

    public static void main(String[] args) {
        Scanner myObj = new Scanner(System.in);
        int ArraySize, choice;

        System.out.print("Input Array Size: ");
        ArraySize = myObj.nextInt();

        int[] myArray = new int[ArraySize];
        int nowSize = 0;
        PrintDisplay();

        do {

            choice = myObj.nextInt();

            switch (choice) {
                case 1:
                    //Assign Element
                    for (int x = 0; x < ArraySize; x++) {
                        System.out.print("#" + (x + 1) + ": ");
                        myArray[x] = myObj.nextInt();
                    }
                    nowSize = ArraySize;
                    System.out.println("Successfully Assigned the Element");
                    PrintDisplay();
                    break;
                case 2:
                    //Display Element
                    for (int x = 0; x < ArraySize; x++) {
                        System.out.print(myArray[x] + " ");
                    }

                    PrintDisplay();
                    System.out.println("Successfully Displayed");
                    break;
                case 3:
                    //insert element
                    if (nowSize >= myArray.length) {

                        System.out.println("Array is full.");
                    } else {
                        System.out.println("Enter Value: ");
                        int index = myObj.nextInt();
                        if (index < 0 || index > nowSize) {
                            System.out.println("Invalid!");
                        } else {
                            System.out.println("Enter value: ");
                            int value = myObj.nextInt();
                            for (int i = nowSize; i > index; i--) {
                                myArray[i] = myArray[i - 1];
                            }
                            myArray[index] = value;
                            nowSize++;
                            System.out.println("Succesfully Inserted!");
                        }
                    }

                    break;
                case 4:
                    // Search Element
                    System.out.print("Enter value to search: ");
                    int search = myObj.nextInt();
                    int foundIndex = -1;
                    for (int i = 0; i < nowSize; i++) {
                        if (myArray[i] == search) {
                            foundIndex = i;
                            break;
                        }
                    }
                    if (foundIndex != -1) {
                        System.out.println("Value found at index " + foundIndex);
                    } else {
                        System.out.println("Value not found.");
                    }
                    break;

                case 5:
                    //delete
                    System.out.print("Enter index to delete (0 to " + (nowSize - 1) + "): ");
                    int delIndex = myObj.nextInt();
                    if (delIndex < 0 || delIndex >= nowSize) {
                        System.out.println("Invalid index.");
                    } else {
                        for (int i = delIndex; i < nowSize - 1; i++) {
                            myArray[i] = myArray[i + 1];
                        }
                        nowSize--;
                        System.out.println("Element deleted.");
                    }

                    
                    break;
                case 6:
                    System.out.println("Exiting program.");
                    break;
                    
                default:
                    System.out.println("Not in Range!");
            }
        } while (choice != 6);

    }

    static void PrintDisplay() {
        System.out.print("===MENU===\n[1]Assign Element\n"
                + "[2]Display Element\n[3]Insert Element\n"
                + "[4]Search Element\n[5]Delete Element\n[6]Exit"
                + "\nChoice: ");
    }

    static int sum(int a, int b) {
        int sum = 0;
        sum = a * b;
        return sum;
    }

}
