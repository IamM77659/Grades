/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package cc006_verginiza_tla1;

import java.util.Scanner;

public class CC006_Verginiza_TLA1 {

    public static void main(String[] args) {
        
        int n = 0; // variable to store number of students
        Scanner input = new Scanner(System.in); // scanner for user input

        // prompt user until number of students is 20 or less
        do {
            System.out.print("Enter the number of Students: ");
            n = input.nextInt();

            if (n > 20) {
                System.out.println("Student limit reached. Please try again.");
            }
        } while (n > 20);

        int[] grades = new int[n]; // array to store grades
        
        

        // loop through each student to input grades
        for (int i = 0; i < n; i++) {

            // validate grade input to be between 0 and 100
            do {
                System.out.print("Enter Grade for Student " + (i + 1) + ": ");
                grades[i] = input.nextInt();
                if (grades[i] > 100 || grades[i] < 0) { // grade limit of not exceeding above 100.
                    System.out.println("Invalid input. Grades must be above 0 but not exceed 100. Please try again.");
                }
            } while (grades[i] > 100 || grades[i] < 0);

        }

        // display computed results
        System.out.print("\nHighest Grade: " + getHighest(grades) + "\n"
                + "Lowest Grade: " + getLowest(grades) + "\n"
                + "Average Grade: " + getAverage(grades) + "\n"
                + "Number of Passed Students: " + countPass(grades) + "\n"
                + "Number of Failed Students: " + countFail(grades) + "\n"
        );

        // print sorted grades
        System.out.print("Sorted Grades: ");
        sortedGrades(grades);

        for (int num : grades) {
            System.out.print(num + " "); // print each sorted grade
        }
        System.out.println(""); // separate build confirmation for cleanliness

    }

    // method to get highest grade
    public static int getHighest(int[] grades) {
        int high = grades[0];

        for (int grade : grades) {
            if (grade > high) {
                high = grade;
            }
        }
        return high;
    }

    // method to get lowest grade
    public static int getLowest(int[] grades) {
        int low = grades[0];

        for (int grade : grades) {
            if (grade < low) {
                low = grade;
            }
        }
        return low;
    }

    // method to compute average grade
    public static double getAverage(int[] grades) {
        int sum = 0;
        for (int num : grades) {
            sum += num;
        }

        double ave = (double) sum / grades.length; // convert to double then calculate the average
        return ave;
    }

    // method to count how many students passed
    public static int countPass(int[] grades) {
        int passCount = 0;
        for (int grade : grades) {
            if (grade >= 75) {
                passCount++;
            }
        }
        return passCount;
    }

    // method to count how many students failed
    public static int countFail(int[] grades) {
        int failCount = 0;
        for (int grade : grades) {
            if (grade < 75) {
                failCount++;
            }
        }
        return failCount;
    }

    // method to sort grades in ascending order using bubble sort
    public static void sortedGrades(int[] grades) {
        for (int i = 0; i < grades.length; i++) {
            for (int j = 0; j < grades.length - 1 - i; j++) {
                if (grades[j] > grades[j + 1]) {
                    // swap grades
                    int temp = grades[j];
                    grades[j] = grades[j + 1];
                    grades[j + 1] = temp;
                }
            }
        }

    }

}
