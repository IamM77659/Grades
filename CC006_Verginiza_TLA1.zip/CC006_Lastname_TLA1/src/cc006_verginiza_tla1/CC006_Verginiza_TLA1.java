/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package cc006_verginiza_tla1;

import java.util.Scanner;

public class CC006_Verginiza_TLA1 {

    public static void main(String[] args) {

        int n = 0; // variable to store number of students
        Scanner input = new Scanner(System.in); // scanner for user input

        // prompt user until number of students is 20 or less
        do {
            System.out.print("Enter the number of Students: ");
            n = input.nextInt();

            if (n > 20) {
                System.out.println("Student limit reached. Please try again.");
            }
        } while (n > 20);

        int[] grades = new int[n]; // array to store grades

        // loop through each student to input grades
        for (int i = 0; i < n; i++) {

            // validate grade input to be between 0 and 100
            do {
                System.out.print("Enter Grade for Student " + (i + 1) + ": ");
                grades[i] = input.nextInt();
                if (grades[i] > 100 || grades[i] < 0) { // grade limit of not exceeding above 100.
                    System.out.println("Invalid input. Grades must be above 0 but not exceed 100. Please try again.");
                }
            } while (grades[i] > 100 || grades[i] < 0);

        }

        // display computed results
        System.out.print("\nHighest Grade: " + getHighest(grades) + "\n"
                + "Lowest Grade: " + getLowest(grades) + "\n"
                + "Average Grade: " + getAverage(grades) + "\n"
                + "Number of Passed Students: " + countPass(grades) + "\n"
                + "Number of Failed Students: " + countFail(grades) + "\n"
        );

        // print sorted grades
        System.out.print("Sorted Grades: ");
        sortedGrades(grades);

        for (int num : grades) {
            System.out.print(num + " "); // print each sorted grade
        }
        System.out.println(""); // separate build confirmation for cleanliness

    }

    // method to get highest grade
    public static int getHighest(int[] grades) {
        int high = grades[0]; // assume the first grade is the highest for now

        for (int grade : grades) { // loop through each grade in the array
            if (grade > high) {     // check if the current grade is higher than the current highest
                high = grade;       // update the highest grade
            }
        }
        return high; // return the highest grade found
    }

// method to get lowest grade
    public static int getLowest(int[] grades) {
        int low = grades[0]; // assume the first grade is the lowest for now

        for (int grade : grades) { // loop through each grade in the array
            if (grade < low) {     // check if the current grade is lower than the current lowest
                low = grade;       // update the lowest grade
            }
        }
        return low; // return the lowest grade found
    }

// method to compute average grade
    public static double getAverage(int[] grades) {
        int sum = 0; // initialize sum to 0

        for (int num : grades) { // loop through each grade
            sum += num; // add the grade to the total sum
        }

        double ave = (double) sum / grades.length; // divide sum by number of grades and convert to double
        return ave; // return the average value
    }

// method to count how many students passed
    public static int countPass(int[] grades) {
        int passCount = 0; // counter for passed students

        for (int grade : grades) { // loop through each grade
            if (grade >= 75) {     // check if grade is 75 or above
                passCount++;       // increment pass counter
            }
        }
        return passCount; // return the number of passed students
    }

// method to count how many students failed
    public static int countFail(int[] grades) {
        int failCount = 0; // counter for failed students

        for (int grade : grades) { // loop through each grade
            if (grade < 75) {      // check if grade is below 75
                failCount++;       // increment fail counter
            }
        }
        return failCount; // return the number of failed students
    }

    // Method to sort grades in ascending order using bubble sort
    public static void sortedGrades(int[] grades) {

        // Outer loop runs for each element in the array
        for (int i = 0; i < grades.length; i++) {

            // Inner loop goes to the unsorted part of the array
            for (int j = 0; j < grades.length - 1 - i; j++) {

                // Compare the current element with the next one
                if (grades[j] > grades[j + 1]) {

                    // If current element is greater, swap them
                    int temp = grades[j];      // Store current element in a temporary variable temp
                    grades[j] = grades[j + 1]; // Move the next element to the current position
                    grades[j + 1] = temp;      // Move the temp (original current) to the next position
                }
            }
        }

    }

}
