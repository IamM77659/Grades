package mystacks;

public class Stacks {

    private int[] arr;
    private int top;
    private int capacity;

    public Stacks(int size) {
        arr = new int[size];
        capacity = size;
        top = -1;
    }

    public void push(int item) {
        if (isFull() == true) {
            

        } else {
            arr[++top] = item;
        }
    }

    public int pop() {
        if (isEmpty()) {
            System.out.println("Stack is empty!");

        }
        return arr[top--];
    }

    public int Top() {
        return arr[top];
    }

    public boolean isEmpty() {
        if (top == -1) {
            return true;
        } else {
            return false;
        }
    }

    public boolean isFull() {
        if (top == capacity - 1) {
            return true;

        } else {
            return false;
        }

    }

    public int size() {
        return top + 1;
    }

    public int Count() {
        return top + 1;
    }
    
    

}
