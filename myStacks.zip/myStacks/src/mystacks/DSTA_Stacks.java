/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package mystacks;

/**
 *
 * @author Students Account
 */
public class DSTA_Stacks {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Stacks st = new Stacks(5);
        
        System.out.println("Stack count: "+ st.Count());
        
        st.push(7);
        st.push(5);
        st.push(2);
        st.push(11);
        st.push(15);
        System.out.println("Stack count: " + st.Count());
        st.push(9);
        st.push(7);
        st.push(4);
        st.push(13);
        st.push(17);
        System.out.println("Stack count: " + st.Count());
        st.pop();
        st.push(100);
        System.out.println("Top: " + st.pop());
        
        
        
        
        
        
        
        
        
        
    }
    
}
